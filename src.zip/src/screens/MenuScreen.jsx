import React, { useMemo, useState } from "react";
import { useParams } from "react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Badge,
  Button,
  Checkbox,
  Image,
  Input,
  Modal,
  Select,
  Spin,
  Table,
  Tag,
  Typography,
  message,
} from "antd";
import {
  CheckCircle2,
  Layers3,
  Search,
  ShieldCheck,
  Store,
  Tag as TagIcon,
} from "lucide-react";
import Layout from "../components/layout/Layout";
import api from "../api/config";
import { image_uri } from "../utils/constants";

const { Title, Text } = Typography;
const { Search: SearchInput } = Input;

function formatMoney(value) {
  return `BDT ${Number(value || 0).toLocaleString("en-BD")}`;
}

function normalizeMenu(menu) {
  const categoryValue =
    typeof menu?.category === "string"
      ? menu.category
      : menu?.category?.name || menu?.category?.title || "Uncategorized";

  const restaurantValue =
    typeof menu?.restaurantId === "string"
      ? menu.restaurantId
      : menu?.restaurantId?._id || menu?.restaurant?._id || "N/A";

  const totalPrice = Number(menu?.basedPrice || 0) + Number(menu?.plateformFee || 0);

  return {
    ...menu,
    key: menu?._id,
    categoryLabel: categoryValue,
    restaurantIdLabel: restaurantValue,
    titleLabel: menu?.title || menu?.name || "Untitled Menu",
    descriptionLabel: menu?.description || "No description",
    totalPrice,
  };
}

function StatusTag({ status }) {
  const normalized = String(status || "").toLowerCase();

  if (normalized === "in stock") {
    return <Tag color="blue">in stock</Tag>;
  }
  if (normalized === "out of stock") {
    return <Tag color="red">out of stock</Tag>;
  }
  if (normalized === "discontinued") {
    return <Tag color="default">discontinued</Tag>;
  }

  return <Tag>{status || "unknown"}</Tag>;
}

function StatsCard({ icon: Icon, label, value, hint }) {
  return (
    <div className="rounded-[24px] border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-slate-400">{label}</p>
          <h3 className="mt-2 text-2xl font-black text-slate-950">{value}</h3>
          <p className="mt-1 text-xs text-slate-500">{hint}</p>
        </div>
        <div className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-blue-200 bg-blue-50 text-blue-600">
          <Icon size={20} />
        </div>
      </div>
    </div>
  );
}

function UpdateDiscountButton({ menuId, currentDiscountRate = 0, queryKey }) {
  const [open, setOpen] = useState(false);
  const [discountRate, setDiscountRate] = useState(currentDiscountRate);
  const queryClient = useQueryClient();

  const handleSubmit = async () => {
    try {
      const { data } = await api.put(`/zone/menu/update-discount-rate`, {
        menuId,
        discountRate: Number(discountRate || 0),
      });

      if (data?.success) {
        message.success(data?.message || "Discount updated successfully");
        setOpen(false);
        queryClient.invalidateQueries({ queryKey });
      }
    } catch (error) {
      message.error(error?.response?.data?.message || "Failed to update discount");
    }
  };

  return (
    <>
      <Button type="primary" size="small" onClick={() => setOpen(true)}>
        Update discount
      </Button>

      <Modal
        open={open}
        title="Update Discount"
        onCancel={() => setOpen(false)}
        onOk={handleSubmit}
        okText="Update"
      >
        <Input
          type="number"
          value={discountRate}
          onChange={(e) => setDiscountRate(e.target.value)}
          placeholder="Enter discount rate"
        />
      </Modal>
    </>
  );
}

function UpdatePlatformFeeButton({ menuId, currentFee = 0, queryKey }) {
  const [open, setOpen] = useState(false);
  const [platformFee, setPlatformFee] = useState(currentFee);
  const queryClient = useQueryClient();

  const handleSubmit = async () => {
    try {
      const { data } = await api.put(`/zone/menu/update-platform-fee`, {
        menuId,
        platformFee: Number(platformFee || 0),
      });

      if (data?.success) {
        message.success(data?.message || "Platform fee updated successfully");
        setOpen(false);
        queryClient.invalidateQueries({ queryKey });
      }
    } catch (error) {
      message.error(error?.response?.data?.message || "Failed to update platform fee");
    }
  };

  return (
    <>
      <Button type="primary" size="small" onClick={() => setOpen(true)}>
        Update fee
      </Button>

      <Modal
        open={open}
        title="Update Platform Fee"
        onCancel={() => setOpen(false)}
        onOk={handleSubmit}
        okText="Update"
      >
        <Input
          type="number"
          value={platformFee}
          onChange={(e) => setPlatformFee(e.target.value)}
          placeholder="Enter platform fee"
        />
      </Modal>
    </>
  );
}

function MenuScreen() {
  const { restaurantId } = useParams();

  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [menuIdSearch, setMenuIdSearch] = useState("");
  const [restaurantIdSearch, setRestaurantIdSearch] = useState("");
  const [statusDrafts, setStatusDrafts] = useState({});

  const queryKey = ["menu", restaurantId];

  const fetchRestaurantMenu = async () => {
    const { data } = await api.get(`/zone/restaurant/menu-list/${restaurantId}`);
    return Array.isArray(data?.result) ? data.result : [];
  };

  const { data: rawMenuData = [], isLoading, isFetching } = useQuery({
    queryFn: fetchRestaurantMenu,
    queryKey,
    enabled: !!restaurantId,
    refetchOnWindowFocus: false,
  });

  const menuData = useMemo(() => rawMenuData.map(normalizeMenu), [rawMenuData]);

  const categoryOptions = useMemo(() => {
    const set = new Set(menuData.map((item) => item.categoryLabel).filter(Boolean));
    return Array.from(set);
  }, [menuData]);

  const filteredData = useMemo(() => {
    return menuData.filter((item) => {
      const rowStatus = String(statusDrafts[item._id] || item.status || "").toLowerCase();
      const menuIdValue = String(item._id || "").toLowerCase();
      const restaurantValue = String(item.restaurantIdLabel || "").toLowerCase();

      const matchesStatus =
        statusFilter === "all" || rowStatus === String(statusFilter).toLowerCase();

      const matchesCategory =
        categoryFilter === "all" || item.categoryLabel === categoryFilter;

      const matchesMenuId = !menuIdSearch.trim()
        ? true
        : menuIdValue.includes(menuIdSearch.trim().toLowerCase());

      const matchesRestaurantId = !restaurantIdSearch.trim()
        ? true
        : restaurantValue.includes(restaurantIdSearch.trim().toLowerCase());

      return matchesStatus && matchesCategory && matchesMenuId && matchesRestaurantId;
    });
  }, [
    menuData,
    statusDrafts,
    statusFilter,
    categoryFilter,
    menuIdSearch,
    restaurantIdSearch,
  ]);

  const stats = useMemo(() => {
    return {
      total: filteredData.length,
      inStock: filteredData.filter(
        (item) => String(statusDrafts[item._id] || item.status).toLowerCase() === "in stock",
      ).length,
      approved: filteredData.filter((item) => !!item.isApproved).length,
      popular: filteredData.filter((item) => !!item.isPopular).length,
    };
  }, [filteredData, statusDrafts]);

  const columns = [
    {
      title: "SL No",
      key: "serial",
      width: 78,
      fixed: "left",
      render: (_, __, index) => (
        <span className="font-semibold text-slate-600">{index + 1}</span>
      ),
    },
    {
      title: "ID",
      dataIndex: "_id",
      key: "_id",
      width: 180,
      render: (value) => (
        <Text copyable className="text-xs text-slate-600">
          {value}
        </Text>
      ),
    },
    {
      title: "Thumbnails",
      dataIndex: "image",
      key: "image",
      width: 100,
      render: (img, record) => (
        <Image
          src={`${image_uri}${img}`}
          alt={record.titleLabel}
          width={56}
          height={56}
          className="rounded-full object-cover"
          fallback="https://via.placeholder.com/56"
        />
      ),
    },
    {
      title: "Restaurant ID",
      dataIndex: "restaurantIdLabel",
      key: "restaurantIdLabel",
      width: 190,
      render: (value) => <Text copyable className="text-xs">{value}</Text>,
    },
    {
      title: "Category",
      dataIndex: "categoryLabel",
      key: "categoryLabel",
      width: 150,
      render: (value) => <Tag color="blue">{value}</Tag>,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 120,
      render: (value, record) => <StatusTag status={statusDrafts[record._id] || value} />,
    },
    {
      title: "Title",
      dataIndex: "titleLabel",
      key: "titleLabel",
      width: 180,
      render: (value) => <Text strong>{value}</Text>,
    },
    {
      title: "Description",
      dataIndex: "descriptionLabel",
      key: "descriptionLabel",
      width: 220,
      ellipsis: true,
      render: (value) => <Text className="text-slate-600">{value}</Text>,
    },
    {
      title: "Based Price",
      dataIndex: "basedPrice",
      key: "basedPrice",
      width: 120,
      render: (value) => <Text strong className="text-green-600">{formatMoney(value)}</Text>,
    },
    {
      title: "PlateformFee",
      dataIndex: "plateformFee",
      key: "plateformFee",
      width: 120,
      render: (value) => <Text strong className="text-slate-600">{formatMoney(value)}</Text>,
    },
    {
      title: "BasedPrice + plateformFee",
      dataIndex: "totalPrice",
      key: "totalPrice",
      width: 170,
      render: (value) => <Text strong className="text-blue-600">{formatMoney(value)}</Text>,
    },
    {
      title: "Discount",
      dataIndex: "discountRate",
      key: "discountRate",
      width: 100,
      render: (value) => <Text strong className="text-orange-500">{Number(value || 0)}%</Text>,
    },
    {
      title: "Offer Price",
      dataIndex: "offerPrice",
      key: "offerPrice",
      width: 120,
      render: (value) => <Text strong className="text-red-500">{formatMoney(value)}</Text>,
    },
    {
      title: "Change status",
      key: "changeStatus",
      width: 150,
      render: (_, record) => (
        <Select
          size="small"
          value={statusDrafts[record._id] || record.status || "in stock"}
          style={{ width: 130 }}
          options={[
            { label: "in stock", value: "in stock" },
            { label: "out of stock", value: "out of stock" },
            { label: "discontinued", value: "discontinued" },
          ]}
          onChange={(value) =>
            setStatusDrafts((prev) => ({
              ...prev,
              [record._id]: value,
            }))
          }
        />
      ),
    },
    {
      title: "Update Discount",
      key: "updateDiscount",
      width: 150,
      render: (_, record) => (
        <UpdateDiscountButton
          menuId={record._id}
          currentDiscountRate={record.discountRate}
          queryKey={queryKey}
        />
      ),
    },
    {
      title: "Update plateformFee",
      key: "updateFee",
      width: 160,
      render: (_, record) => (
        <UpdatePlatformFeeButton
          menuId={record._id}
          currentFee={record.plateformFee}
          queryKey={queryKey}
        />
      ),
    },
    {
      title: "Admin Approval",
      dataIndex: "isApproved",
      key: "isApproved",
      width: 130,
      render: (value) => <Checkbox checked={!!value} disabled />,
    },
    {
      title: "Popular",
      dataIndex: "isPopular",
      key: "isPopular",
      width: 100,
      render: (value) => <Checkbox checked={!!value} disabled />,
    },
  ];

  if (isLoading) {
    return (
      <Layout>
        <div className="flex min-h-[80vh] items-center justify-center">
          <Spin size="large" tip="Loading menu items..." />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-4 p-4 md:p-6">
        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
            <div>
              <p className="text-[11px] uppercase tracking-[0.28em] text-blue-600">
                Food Verse Agent Menu Control
              </p>
              <Title level={2} style={{ margin: "8px 0 0", fontWeight: 900 }}>
                Menu Management
              </Title>
              <Text type="secondary">All menus with full pricing, approval and control columns.</Text>
              {!restaurantId ? (
                <div className="mt-3">
                  <Tag color="volcano">No restaurantId found in route</Tag>
                </div>
              ) : null}
            </div>

            <div className="flex items-center gap-2 self-start rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
              <Badge status={isFetching ? "processing" : "success"} />
              <span className="text-sm font-medium text-slate-700">
                {isFetching ? "Refreshing data..." : "Live data ready"}
              </span>
            </div>
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <StatsCard icon={Layers3} label="Total Menus" value={stats.total} hint="Filtered result count" />
            <StatsCard icon={CheckCircle2} label="In Stock" value={stats.inStock} hint="Available menu items" />
            <StatsCard icon={ShieldCheck} label="Approved" value={stats.approved} hint="Admin approved items" />
            <StatsCard icon={TagIcon} label="Popular" value={stats.popular} hint="Popular tagged items" />
          </div>

          <div className="mt-5 grid gap-3 lg:grid-cols-5">
            <Select
              value={statusFilter}
              onChange={setStatusFilter}
              options={[
                { label: "all", value: "all" },
                { label: "in stock", value: "in stock" },
                { label: "out of stock", value: "out of stock" },
                { label: "discontinued", value: "discontinued" },
              ]}
              size="large"
            />

            <Select
              value={categoryFilter}
              onChange={setCategoryFilter}
              options={[
                { label: "Filter category", value: "all" },
                ...categoryOptions.map((item) => ({ label: item, value: item })),
              ]}
              size="large"
            />

            <SearchInput
              allowClear
              size="large"
              placeholder="Input menu id"
              prefix={<Search size={15} className="text-slate-400" />}
              value={menuIdSearch}
              onChange={(e) => setMenuIdSearch(e.target.value)}
              onSearch={setMenuIdSearch}
            />

            <SearchInput
              allowClear
              size="large"
              placeholder="Input restaurant id"
              prefix={<Store size={15} className="text-slate-400" />}
              value={restaurantIdSearch}
              onChange={(e) => setRestaurantIdSearch(e.target.value)}
              onSearch={setRestaurantIdSearch}
            />

            <Button
              size="large"
              onClick={() => {
                setStatusFilter("all");
                setCategoryFilter("all");
                setMenuIdSearch("");
                setRestaurantIdSearch("");
              }}
            >
              Clear Filters
            </Button>
          </div>
        </div>

        <div className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-sm">
          <Table
            rowKey="_id"
            columns={columns}
            dataSource={filteredData}
            pagination={{ pageSize: 10, showSizeChanger: false }}
            scroll={{ x: 2600 }}
            size="middle"
            bordered={false}
          />
        </div>
      </div>
    </Layout>
  );
}

export default MenuScreen;
